#include <sys/time.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  struct timeval firsttv; /* first tv after last descheduling */
  struct timeval lasttv, prevtv; /* last and previous tv */
  if (argc > 1) {
    unsigned seconds = atoi(argv[1]);
    printf("sleeping %d seconds\n", seconds);
    sleep(seconds);
  }
  pid_t pid = getpid();
  gettimeofday(&lasttv, NULL);
  firsttv = lasttv;
  while (1) {
    unsigned long lastus, myus;
    prevtv = lasttv;
    gettimeofday(&lasttv, NULL);
    lastus = (lasttv.tv_sec-prevtv.tv_sec)*1000000+(lasttv.tv_usec-prevtv.tv_usec);
    if (lastus > 1000) {
      /* we ran from firsttv to prevtv and did not run from prevtv to lasttv */
      myus = (prevtv.tv_sec-firsttv.tv_sec)*1000000+(prevtv.tv_usec-firsttv.tv_usec);
      printf("\r%d - run during %ldus - did not run during %ldus", pid, myus, lastus);
//      printf("%d - run during %ldus - did not run during %ldus\n", pid, myus, notmyus);
      firsttv = lasttv;
    }
  }
  return 0;
}
