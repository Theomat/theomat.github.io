#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  int affiche = 0;
  if (argc > 1)
    affiche = atoi(argv[1]);
  printf("affichage = %d\n", affiche);

  while (1) {
    if (affiche)
      printf("iteration\n");
  }

  return 0;
}
