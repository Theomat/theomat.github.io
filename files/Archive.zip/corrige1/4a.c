#include <sys/time.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  struct timeval prevtv,lasttv;
  unsigned long us;
  unsigned min = 1000;
  pid_t pid = getpid();
  if (argc > 1)
    min = atoi(argv[1]);
  gettimeofday(&lasttv, NULL);
  while (1) {
    prevtv = lasttv;
    gettimeofday(&lasttv, NULL);
    us = (lasttv.tv_sec-prevtv.tv_sec)*1000000+(lasttv.tv_usec-prevtv.tv_usec);
    if (us >= min)
      printf("pid %d : %ld us\n", pid, us);
  }
  return 0;
}
