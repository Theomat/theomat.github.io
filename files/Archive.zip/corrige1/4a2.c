#include <sys/time.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
  struct timeval tv[2];
  unsigned long us;
  unsigned min = 1000;
  int i = 0;
  pid_t pid = getpid();
  if (argc > 1)
    min = atoi(argv[1]);
  gettimeofday(&tv[!i], NULL);
  while (1) {
    gettimeofday(&tv[i], NULL);
    us = (tv[i].tv_sec-tv[!i].tv_sec)*1000000+(tv[i].tv_usec-tv[!i].tv_usec);
    if (us >= min)
      printf("pid %d : %ld us\n", pid, us);
    i = !i;
  }
  return 0;
}
