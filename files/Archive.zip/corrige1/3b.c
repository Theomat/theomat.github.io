#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <asm/unistd.h>

/* eviter de compiler avec -std=c99, sinon il faut definir _GNU_SOURCE */

int main(int argc, char *argv[]) {
  unsigned long microseconds;
  struct timeval tv1, tv2;
  int i;

 if (argc == 1 || atoi(argv[1]) == 1) {
#define NGTOD 10000000
  gettimeofday(&tv1, NULL);
  for(i=0;i<NGTOD;i++)
    gettimeofday(&tv2, NULL);
  microseconds = (tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
  printf("gettimeofday = %lu ns (%lu for %u)\n", microseconds*1000/NGTOD, microseconds, NGTOD);
 }

 if (argc == 1 || atoi(argv[1]) == 2) {
#define NGTOD 10000000
  gettimeofday(&tv1, NULL);
  for(i=0;i<NGTOD;i++)
    syscall(__NR_gettimeofday, &tv2, NULL);
  microseconds = (tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
  printf("vrai gettimeofday = %lu ns (%lu for %u)\n", microseconds*1000/NGTOD, microseconds, NGTOD);
 }

 if (argc == 1 || atoi(argv[1]) == 3) {
#define NGP 1000000
  gettimeofday(&tv1, NULL);
  for(i=0;i<NGP;i++)
    getpid();
  gettimeofday(&tv2, NULL);
  microseconds = (tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
  printf("getpid = %lu ns (%lu for %u)\n", microseconds*1000/NGP, microseconds, NGP);
 }

 if (argc == 1 || atoi(argv[1]) == 4) {
#define NGP 1000000
  gettimeofday(&tv1, NULL);
  for(i=0;i<NGP;i++)
    syscall(__NR_getpid);
  gettimeofday(&tv2, NULL);
  microseconds = (tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
  printf("vrai getpid = %lu ns (%lu for %u)\n", microseconds*1000/NGP, microseconds, NGP);
 }

  return 0;
}
