#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>

int main()
{
  unsigned long microseconds;
  struct timeval tv1, tv2;
  gettimeofday(&tv1, NULL);
  sleep(2);
  gettimeofday(&tv2, NULL);
  microseconds = (tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
  printf("%lu us\n", microseconds);
  return 0;
}
