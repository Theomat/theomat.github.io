#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <math.h>

int main(){
  static char cmd[64];
  size_t length;
  void *ptr;
  long int i,size;

  sprintf(cmd, "cat /proc/%u/maps", getpid());

  printf("#######################\n");
  printf("growing mmap...\n");
  length = 1048576;
  while(1){
    ptr=mmap(NULL,length,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON,-1,0);
    if(ptr==MAP_FAILED){
      printf("mmap failed with length: %f Go (%m)\n",length/(1024.0*1024.0*1024.0));
      break;
    }
    munmap(ptr,length);
    length*=2;
  }

  printf("#######################\n");
  printf("growing mmap NORESERVE...\n");
  length = 1048576;
  while(1){
    printf("##### trying with %lu MB\n", length/1048576);
    ptr=mmap(NULL,length,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON|MAP_NORESERVE,-1,0);
    if(ptr==MAP_FAILED){
      printf("mmap NORESERVE failed with length: %f Go (%m)\n",length/(1024.0*1024.0*1024.0));
      break;
    }
    system(cmd);
    munmap(ptr,length);
    length*=2;
  }

  printf("#######################\n");
  printf("lots of 1Go mmap\n");
  length=1024*1024*1024l;
  i=0;
  while(1){
    i++;
    ptr=mmap(NULL,length,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANON|MAP_NORESERVE,-1,0);
    if(ptr==MAP_FAILED){
      printf("mmap failed after %ld mmap of 1 Go. Total: %.3f To\n",i-1,(i-1)/1024.0);
      size=(i-1)*length;
      printf("nb bits: %d\n",(int)(ceil(log(size)/log(2))));
      exit(-1);
    }
  }

}
