#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdlib.h>

static char cmd[64];
static char cmd2[256];
static char *lasts;
static int lasti;

static void f(int i)
{
  char s[10000];
  if (!(i%100)) {
    printf("##### appel n°%u\n", i);
    fflush(stdout);
    system(cmd);
    system(cmd2);
  }
  lasts = s;
  lasti = i;
  f(i+1);
}

void g(int sig) {
  printf("###################################\n");
  printf("dernier buffer = %p\n", lasts);
  printf("dernier i = %d\n", lasti);
  printf("###################################\n");
  fflush(stdout);
  system(cmd);
  system(cmd2);
  exit(-1);
}

int main()
{
  struct sigaction act;
  stack_t ss;
  void *ptr;
  int err;

  ptr=malloc(SIGSTKSZ); /* alloue de la mémoire pour cette nouvelle pile afin que le gestionaire de signal puisse s'exécuter dessus*/
  ss.ss_sp=ptr;
  ss.ss_flags=0;
  ss.ss_size=SIGSTKSZ;
  err = sigaltstack(&ss,NULL);
  if (err < 0)
    perror("sigaltstack");

  act.sa_handler= g; /*défini le gestionaire de signal*/
  act.sa_flags=SA_ONSTACK;
  sigaction(SIGSEGV,&act,NULL);

  sprintf(cmd, "cat /proc/%u/maps", getpid());
  sprintf(cmd2, "grep '\\[stack\\]' /proc/%u/maps | cut -d' ' -f1 | tr a-f A-F | sed -r -e 's/-/+/' -e 's/^/ibase=16;(-/' -e 's@$@)@' | bc | sed -r -e 's/(.*)/pile de \\1 octets/'", getpid());

  f(0);
  return 0;
}
